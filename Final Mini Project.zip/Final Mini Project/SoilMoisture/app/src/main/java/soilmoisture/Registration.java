package com.example.soilmoisture;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registration extends AppCompatActivity {


    EditText fname,mail,mob,pwd;
    private FirebaseAuth firebaseAuth;
    String f_name,Email,pass1,phone,id;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        fname=findViewById(R.id.fname);
        mail=findViewById(R.id.email);
        mob=findViewById(R.id.mobile);
        pwd=findViewById(R.id.passd);

        firebaseAuth=FirebaseAuth.getInstance();
    }

    public void submit(View view)
    {
        validate();
    }
       /* if (validate())
        {
            String usremail=mail.getText().toString().trim();
            String usrpwd=pwd.getText().toString().trim();

            firebaseAuth.createUserWithEmailAndPassword(usremail,usrpwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        senduserData();

                        Toast.makeText(Registration.this, "Registration Succssesfull", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Registration.this,MainActivity.class));
                    }
                    else
                    {
                        Toast.makeText(Registration.this, "Registration Failed", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
    } */

    private void validate()
    {
        f_name=fname.getText().toString();
        Email=mail.getText().toString();
        pass1=pwd.getText().toString();
        phone=mob.getText().toString();

        if (f_name.isEmpty()  || Email.isEmpty() || pass1.isEmpty() || phone.isEmpty())
        {
            Toast.makeText(this, "Please enter all thr details", Toast.LENGTH_SHORT).show();

        }
        else
        {

            String usremail=mail.getText().toString().trim();
            String usrpwd=pwd.getText().toString().trim();

            firebaseAuth.createUserWithEmailAndPassword(usremail,usrpwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        id=firebaseAuth.getUid();
                        senduserData();

                        Toast.makeText(Registration.this, "Registration Succssesfull", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Registration.this,MainActivity.class));
                    }
                    else
                    {
                        Toast.makeText(Registration.this, "Registration Failed", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }

    }

/*    private boolean validate()
    {
        Boolean result=false;

         f_name=fname.getText().toString();
         Email=mail.getText().toString();
         pass1=pwd.getText().toString();
         phone=mob.getText().toString();


        if (f_name.isEmpty()  || Email.isEmpty() || pass1.isEmpty() || phone.isEmpty())
        {
            Toast.makeText(this, "Please enter all thr details", Toast.LENGTH_SHORT).show();

        }
        else
        {
            result=true;
        }
        return result;

    }
*/
    private void senduserData()
    {
        FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
        DatabaseReference myref=firebaseDatabase.getReference("Users");
        Userprofile userprofile=new Userprofile(f_name,phone,Email,pass1);
        myref.child(id).setValue(userprofile);
    }
}
