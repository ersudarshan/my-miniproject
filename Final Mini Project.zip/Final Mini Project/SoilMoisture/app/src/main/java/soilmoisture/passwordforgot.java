package com.example.soilmoisture;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class passwordforgot extends AppCompatActivity {

    EditText email;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwordforgot);

        email=findViewById(R.id.edittextemail);
        firebaseAuth=FirebaseAuth.getInstance();
    }

    public void reset(View view)
    {
    String mail=email.getText().toString().trim();
    if (mail.isEmpty())
    {
        Toast.makeText(this, "Please enter your registered Email address", Toast.LENGTH_SHORT).show();
    }
    else
    {
        firebaseAuth.sendPasswordResetEmail(mail).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if ((task.isSuccessful()))
                {
                    Toast.makeText(passwordforgot.this, "Password reset Email send", Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(new Intent(passwordforgot.this,MainActivity.class));
                }
                else
                {
                    Toast.makeText(passwordforgot.this, "Error in sending password reset email", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
    }
}
