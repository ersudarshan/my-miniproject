package com.example.soilmoisture;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    EditText un,pw;
    TextView fp;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        un=findViewById(R.id.lgn);
        pw=findViewById(R.id.pwd);
        fp=findViewById(R.id.forgot);


            firebaseAuth=FirebaseAuth.getInstance();
            progressDialog=new ProgressDialog(this);



    }

    public void login(View view) {
        String uname = un.getText().toString();
        String pass = pw.getText().toString();
        if (uname.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Plaese fill all the fields", Toast.LENGTH_SHORT).show();
        } else {
            validate(un.getText().toString(), pw.getText().toString());

        }
    }

    public void register(View view)
    {
        Intent i=new Intent(this,Registration.class);
        startActivity(i);
    }

    public void forgot(View view)
    {
        startActivity(new Intent(MainActivity.this,passwordforgot.class));
    }

    private void validate(String usrname,String usrpass) {


        progressDialog.setMessage("Wait until it verified");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(usrname, usrpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                    progressDialog.dismiss();
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                    FirebaseUser user=firebaseAuth.getCurrentUser();
                    if (user!=null)
                    {
                        finish();
                        startActivity(new Intent(MainActivity.this,HP.class));
                    }

                   // startActivity(new Intent(MainActivity.this,HP.class));

                }
                else
                {
                    progressDialog.dismiss();
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }



}
