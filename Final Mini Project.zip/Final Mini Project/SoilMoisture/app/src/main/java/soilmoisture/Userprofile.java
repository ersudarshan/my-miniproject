package com.example.soilmoisture;

public class Userprofile {

    public String fname;
    public String mob;
    public String mail;
    public String pwd;

    public Userprofile(String fname, String mob, String mail, String pwd) {
        this.fname = fname;
        this.mob = mob;
        this.mail = mail;
        this.pwd = pwd;
    }
}
